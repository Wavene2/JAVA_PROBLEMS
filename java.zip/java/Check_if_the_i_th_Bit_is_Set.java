public class Check_if_the_i_th_Bit_is_Set {
}
