import java.util.Scanner;

public class odd_even {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        if ((a & 1) == 1) {
            System.out.println("even");
        } else {
            System.out.println("odd");
        }

    }
}
