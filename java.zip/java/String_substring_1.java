public class String_substring_1 {
    public static void main(String[] args) {

    }
}
